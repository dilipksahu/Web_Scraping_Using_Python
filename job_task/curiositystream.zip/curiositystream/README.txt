
# Commands Used

scrapy startproject curiositystream 

scrapy genspider movies https://curiositystream.com/categories

scrapy crawl movies

scrapy crawl movies curiosity_data.jsom